CREATE DATABASE cadastro;

CREATE TABLE  cadastro.usuario (
  `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `login` varchar(220) DEFAULT NULL,
  `senha` varchar(220) DEFAULT NULL
);

CREATE TABLE cadastro.publicacao(
    `id` INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `titulo` VARCHAR(40) DEFAULT NULL,
    `conteudo` varchar(256) DEFAULT NULL,
    `data_hora_criacao` TIMESTAMP NOT NULL,
    `usuario_id` int(11) not null
);
CREATE TABLE cadastro.comentario(
    `id` INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `content` VARCHAR(40) DEFAULT NULL,
    `data_hora_criacao` TIMESTAMP NOT NULL,
    `publicacao_id` int(11) not null
);
-- Extraindo dados da tabela `usuario`
--

ALTER TABLE cadastro.publicacao
ADD CONSTRAINT fk_usuario_id
FOREIGN KEY (usuario_id)
REFERENCES cadastro.usuario(id);

ALTER TABLE cadastro.comentario
ADD CONSTRAINT fk_publicacao_id
FOREIGN KEY (publicacao_id)
REFERENCES cadastro.publicacao(id);



INSERT INTO `cadastro`.`usuario` ( `login`, `senha`)
VALUES ('nicole', '232352');
INSERT INTO `cadastro`.`usuario` ( `login`, `senha`)
VALUES ('alvaro', '1234');
 INSERT INTO `cadastro`.`usuario` ( `login`, `senha`)
VALUES ('outro', '1234');
 
INSERT INTO `cadastro`.`publicacao` ( `titulo`, `conteudo`, `usuario_id`)
VALUES ('testando publicações', 'conteúdo', 1);
 
INSERT INTO `cadastro`.`comentario` ( `content`, `publicacao_id`)
VALUES ('testando comentários', 1);
 