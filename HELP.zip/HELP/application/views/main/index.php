<?php $this->load->view('header') ?>

<header>
    <div class="container-fluid">
            <h1 class="texto1" id="titulo"> Helpmotional</h1>
                        
                    <h3 class="texto2" id="subtitulo"> Ajuda emocional e saúde mental</h3>

        
    </div>
        <a href="<?= base_url('index.php/login/logout'); ?>">
        <div class="btn btn-outline-success" style="margin-top: 122px;
margin-bottom: -140px;
margin-left: -30px;">
            <i class="text-light fas fa-power-off"></i>
        </div>        
        </a>
</header>

<main style="margin-top:452px;">
    <div class="container-lg" style="padding-left: 0; padding-right: 0;">
    <div class="row">
        <div class="col-sm-3">
                <a href="<?= base_url('index.php/quero/index') ?>" class="botao fs-13" id="quero">
                Quero ajuda
            </a>

        </div>
        <div class="col-sm-3">
              <a href="<?= base_url('index.php/preciso/index') ?>" class="botao fs-13" id="preciso">
                    Preciso de ajuda
                </a>

        </div>
        <div class="col-sm-3">

        <a href="<?= base_url('index.php/materiais/index') ?>" class="botao fs-13" id="materiais">Materiais
            	</a>

        </div>
        <div class="col-sm-3">

                <a href="<?= base_url('index.php/pscicologos/index') ?>" class="botao fs-11" id="psico">
                    Encontrar psicólogo
                </a>

        </div>
    </div>
    </div>

		
</main>
<?php $this->load->view('footer') ?>