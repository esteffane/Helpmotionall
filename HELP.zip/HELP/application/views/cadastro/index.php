<?php $this->load->view('header') ?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
		
				</div>

				<form method="POST" action="<?= base_url('index.php/usuario/salvar')?>">
					<span class="login100-form-title">
                        Cadastro </br>
                        <small>Já tem cadastro? <a href="<?= base_url('index.php/login') ?>"> Login</a> </small>
					</br>
						
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Campo obrigatório">
						<input class="input100" type="text" name="login" id="login" placeholder="login"> 
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>
					<h6 id="tip"> Você pode ativar o modo anônimo nas configurações </h6> </br>
					<div class="wrap-input100 validate-input" data-validate = "Campo obrigatório">
						<input class="input100" type="password" name="senha" id="senha" placeholder="Senha">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<input class="login100-form-btn" type="submit" value="cadastrar" id="cadastrar" name="cadastrar"><br>
							
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>

<?php $this->load->view('footer') ?>
