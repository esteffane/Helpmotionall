<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title><?= $pagina; ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?= base_url('assets/images/icons/favicon.png')?>"/>
    <link rel="stylesheet" href="<?= base_url('assets/css/all.min.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.min.css')?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css')?> ">
    <script defer="" src="https://kit.fontawesome.com/655272e9b6.js"></script>
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/util.css')?>">
    <?php if(isset($css_login)){?>
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/login.css')?>">
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/main.css')?>">
    <?php }else{?>
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/main.css')?>">
    <?php }?>
    
    <?php if(isset($css_extra)){
        ?>
            <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/extra_css.css')?>">
    <?php }?>
    <?php if(isset($css_preciso)){?>
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/css_preciso.css')?>">
        <?php }?>
        <?php if(isset($css_quero)){?>
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/css_quero.css')?>">
        <?php }?>
        <?php if(isset($css_pscicos)){?>
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/css_psicologos.css')?>">
        <?php }?>
        <?php if(isset($css_materiais)){?>
        <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/css_materiais.css')?>">
        <?php }?>
</head>

<body <?php 
    
if(isset($fundo)){
    echo "background='".$fundo."'";
} 
    if(isset($css_preciso)){
        echo "class='body'";
    }
    if(isset($css_quero)){
        echo "class='body'";
    }
?>>	