<?php $this->load->view('header') ?>
<main>
	<header id="cabecalho">
		<nav>
		<h1 id="titulo"> Preciso de ajuda </h1>
	</nav>
	</header>
	<aside class="lateral"> <h1>Ir para </h1>
	

	<a href="quero.html" class="botao" id="preciso">
		Quero ajudar
	</a>

	<a href="materiais.html" class="botao" id="materiais">
		Materiais
	</a>

	<a href="psicologos.html" class="botao" id="psico">
		Encontrar psicólogo
	</a>
	</aside>
    <form  class="form-group" action="<?= base_url('index.php/preciso/atualizar') ?>" method="POST">
    <div id="caixa"> <h2> Compartilhe o que está sentindo</h2>
        <input type="hidden" name="id" value="<?= $publicacao->id; ?>">
		<input type="text" name="titulo"  class="form-control mb-2" id="" value="<?= $publicacao->titulo;?>" placeholder="insira o título" >
		<textarea class="form-control" id="text" rows="6" cols="5" maxlength="700" name="conteudo" placeholder="insira a sua angústia">
					<?= $publicacao->conteudo;?>
		</textarea> 
		<button class="botao" type="submit" id="postar"> Atualizar</button>
    

    </form>
    
    
	
</main>
<?php $this->load->view('footer') ?>