<?php $this->load->view('header') ?>
<main>
	<header id="cabecalho">
		<nav>
		<h1 id="titulo"> Preciso de ajuda </h1>
	</nav>
	</header>
	<aside class="lateral"> <h1>Ir para </h1>
	

	<a href="<?= base_url('index.php/quero/')?>" class="botao" id="preciso">
		Quero ajuda
	</a>

	<a href="<?= base_url('index.php/materiais/')?>" class="botao" id="materiais">
		Materiais
	</a>

	<a href="<?= base_url('index.php/pscicologos/')?>" class="botao" id="psico">
		Encontrar psicólogo
	</a>
	</aside>

	
    <form  class="form-group" action="<?= base_url('index.php/preciso/salvar') ?>" method="POST">
	<div id="caixa"> <h2> Compartilhe o que está sentindo</h2>
		<input type="text" name="titulo"  class="form-control mb-2" id="" placeholder="insira o título" >
		<textarea class="form-control" id="text" rows="3" cols="5" maxlength="700" name="conteudo" placeholder="insira a sua angústia"></textarea> 
		<button class="botao" type="submit" id="postar"> Postar</button>
    

    </form>
	<?php if($this->session->flashdata('success')){?>
					<div class="alert alert-success" role="alert" style="margin-top: 90px;">
						<?= $this->session->flashdata('success');?>
					</div>
				<?php }elseif($this->session->flashdata('error')){?>
                    <div class="alert alert-danger" role="alert" style="margin-top: 90px;">
						<?= $this->session->flashdata('error');?>
					</div>
                <?php }?>

    <section class="" style="margin-top: 90px; margin-bottom: 90px;">
    		<hr>
        <?php foreach($publics as $public){?>
			
			

				<h1><?= $public->titulo;?></h1> <?php if($public->usuario_id == $this->session->userdata('usuario_logado')['id'])
				{ ?> <div style='margin-left: 23px;'>
					<a href="<?= base_url('index.php/preciso/editar/').$public->id; ?>">editar</a>
					<a href="<?= base_url('index.php/preciso/deletar/').$public->id; ?>"> excluir</a>	</div> 
				<?php } ?>
				<small style="margin-left: 23px;" > <?= $public->data_hora_criacao;?></small>
                <p style="margin-left: 23px;" ><?= $public->conteudo;?></p>
				<a style="margin-left: 23px;" class="btn btn-outline-success line-orange" href="<?= base_url('index.php/quero/ajudarUm/').$public->id; ?>">Comentar</a>
                
                <hr>
                
                   
        <?php }?>   
    </section>
        	<section class="dicas" style="top: 120px;
		left: 900px;">
        		

        		<h2> Ou, tente um destes:</h2>

<p><h5>Centro de Atenção Psicosocial (CAPS)</h5></p>
<ul>	
<li><a href="http://portalms.saude.gov.br/saude-para-voce/saude-mental/acoes-e-programas-saude-mental/centro-de-atencao-psicossocial-caps" target="_blank" rel="noopener">Clique Aqui!</a></li>
</ul>
			
<p><h4>Movimento Setembro Amarelo, Dia mundial de Prevenção ao Suicídio</h4></p>
<ul>
	
<li><a href="http://www.setembroamarelo.org.br/" target="_blank" rel="noopener noreferrer"> Clique Aqui!</a></li>
</ul>
			
<p><h5>Educação Emocional</h5></p>
<ul>
	
<li><a href="http://www.amigosdozippy.org.br/" target="_blank" rel="noopener noreferrer">Clique Aqui!</a></li>
</ul>
			
<p><h5>Associação Brasileira de Psiquiatria</h5></p>
<ul>
	
<li><a href="http://www.abp.org.br/" target="_blank" rel="noopener noreferrer">Clique Aqui!</a></li>
</ul>
			
<p><h5>Movimento Conte Comigo, Prevenção a Depressão</h5></p>
<ul>
	
<li><a href="http://www.contecomigo.org.br/" target="_blank" rel="noopener noreferrer">Clique Aqui!</a></li>
</ul>
			
<p><h5>Rede Brasiliera de Prevenção ao Suicídio</h5></p>
<ul>
	
<li><a href="http://www.rebraps.com.br/" target="_blank" rel="noopener noreferrer">Clique Aqui!</a></li>
</ul>

		</section>

    </div>
     </div>
    	 </div>
	
</main>
<?php $this->load->view('footer') ?>