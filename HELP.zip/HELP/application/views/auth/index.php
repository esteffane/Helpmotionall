<?php $this->load->view('header') ?>
<div class="limiter">
	<div class="container-login100">
		<div class="wrap-login100">
			<div class="login100-pic js-tilt" data-tilt>
			</div>
        
            <?php if($this->session->flashdata('success')){?>
					<div class="alert alert-success" role="alert" >
						<?= $this->session->flashdata('success');?>
					</div>
				<?php }elseif($this->session->flashdata('error')){?>
                    <div class="alert alert-danger" role="alert">
						<?= $this->session->flashdata('error');?>
					</div>
                <?php }?>
				
			<form action="<?= base_url('index.php/login/autenticar')?>" method="post" class="login100-form validate-form">
					<span class="login100-form-title">
						Login </br>
					</br>
						<h6> Não tem login? <a href="<?= base_url('index.php/usuario/formadd') ?>"> Cadastre-se!</a> </h6>
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Campo obrigatório">
						<label>Login:</label><input class="input100" type="text" name="login" id="login" placeholder="login">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i style="margin-top: 30px;" class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Campo obrigatório">
						<label>Senha:</label><input class="input100" type="password" name="senha" id="senha" placeholder="Senha">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i style="margin-top: 30px;" class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<input class="login100-form-btn" type="submit" value="entrar" id="entrar" name="entrar"><br>
					</div>
				</form>
			</div>
		</div>
	</div>

<?php $this->load->view('footer') ?>
