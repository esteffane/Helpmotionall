<?php $this->load->view('header') ?>

<main>
	<header id="cabecalho">
		<nav>
		<h1 id="titulo"> Quero ajuda </h1>
	</nav>
	</header>
	<aside class="lateral"> <h1>Ir para </h1>
	
	<a href="<?= base_url('index.php/preciso/index')?>" class="botao" id="preciso">
		Preciso de ajuda
	</a>

	<a href="<?= base_url('index.php/materiais/')?>" class="botao" id="materiais">
		Materiais
	</a>

	<a href="<?= base_url('index.php/pscicologos/')?>" class="botao" id="psico">
		Encontrar psicólogo
	</a>
	</aside>
    <div class="container" style="margin-top: 141px;">
  
		<div class="row">
			<div class="col-sm-4"></div>
			<div class="col-sm-4">
            <?php if($this->session->flashdata('success')){?>
					<div class="alert alert-success" role="alert" style="margin-top: 90px;">
						<?= $this->session->flashdata('success');?>
					</div>
				<?php }elseif($this->session->flashdata('error')){?>
                    <div class="alert alert-danger" role="alert" style="margin-top: 90px;">
						<?= $this->session->flashdata('error');?>
					</div>
                <?php }?>
			<div class="post mb-3"   > 
				
				<h6> 	<?= $publics->data_hora_criacao;?></h6>
				<h4> 	<?= $publics->titulo;?> </h4> 
				<p>
						<?= $publics->conteudo;?>
				</p>
				
					<form class=" "action="<?= base_url('index.php/quero/salvarUm')?>" method="post">
					<div class="form-group">
						<input type="hidden" name="id_public" value="<?= $publics->id; ?>">
						
						<input class="form-control" id="coment" name="content" placeholder=" adicionar um comentário...">
						<button type="submit" class="btn btn-outline-success line-orange">Comentar</button>
								 
						</div>
					</form>

						<?php foreach($comentarios as $coment){
							if($coment->publicacao_id == $publics->id){
							?>
							<p>
                                <?= $coment->content;?>
                                <a  class="btn btn-outline-success line-orange" href="<?= base_url('index.php/quero/editar/').$coment->id;?>">Editar</a>
                                <a class="btn btn-outline-success line-orange" href="<?= base_url('index.php/quero/deletar/').$coment->id;?>">Excluir</a>
                           
                            </p>
                           
                           
						<?php }
								}?>
				
			</div>
		
			<div class="col-sm-4"></div>
		
		</div>
	</div>
	
</main>



<?php $this->load->view('footer') ?>