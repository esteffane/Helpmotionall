<?php $this->load->view('header') ?>

<header>
    <div class="container-fluid">
            <h1 class="texto1" id="titulo"> Helpmotional</h1>
                        
                    <h3 class="texto2" id="subtitulo"> Ajuda emocional e saúde mental</h3>

        
    </div>
        <a href="<?= base_url('index.php/home/'); ?>">
        <div class="btn btn-outline-success" style="margin-top: 122px;
margin-bottom: -140px;
margin-left: -30px;">
            Logar
        </div>        
        </a>
</header>
<?php $this->load->view('footer') ?>