<?php $this->load->view('header') ?>
<main>
        <header id="cabecalho">
            <nav>
            <h1 id="titulo"> Encontrar psicólogo </h1>
        </nav>

        <aside class="lateral"> <h1 id="ir"> Ir para </h1>

        <a href="preciso.html" class="botao" id="preciso">
            Preciso de ajuda
        </a>

        <a href="materiais.html" class="botao" id="materiais">
            Materiais
        </a>

        <a href="quero.html" class="botao" id="psico">
            Quero ajuda
        </a>
        </aside>

        </header>
        <h2 id="legenda"> Clínicas na sua região </h2>
        <iframe class="mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127020.60413701535!2d-35.29228474941788!3d-5.799914645968561!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7b3aaac26460531%3A0x5d8b404cf00fed69!2sNatal%2C+RN!5e0!3m2!1spt-BR!2sbr!4v1545917243915" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</main>
<?php $this->load->view('footer') ?>