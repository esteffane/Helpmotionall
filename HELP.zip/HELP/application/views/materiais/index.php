<?php $this->load->view('header') ?>
<main>
	<header id="cabecalho">
		<nav>
		<h1 id="titulo"> Materiais úteis </h1>
	</nav>
</header>

<aside class="lateral"> <h1 id="ir"> Ir para </h1>
	<div style= position: absolute;
	height: 350px;
	border-style: solid;
	border-width: 5px;
	border-color: #AFAFAF;
	border-radius: 20px; 
	left: 15px;
	top: 100px;>

<a href="quero.html" class="botao" id="psico">
		Quero ajuda
	</a>
	<a href="preciso.html" class="botao" id="preciso">
		Preciso de ajuda
	</a>

	<a href="psicologos.html" class="botao" id="materiais">
		Encontrar psicólogo
	</a>
</div>
	</aside>
		
</main>
<div id="materi">
<ul>
	<p> <h3>Como ficar calmo em situações problematicas</h3></p>

		<li><a href= "https://www.miguellucas.com.br/saiba-como-manter-se-calmo-em-situacoes-problematicas"/> Acessar </li>
	</ul>

<ul>
	<p> <h3>Exercícios de respiração </h3> </p>
		<li><a href="https://www.google.com/search?ei=zYAlXOW-DcajwgSDoa-wBw&q=exercicio+de+respira%C3%A7%C3%A3o&oq=exercicio+de+respira%C3%A7%C3%A3o&gs_l=psy-ab.3..0i7i30" /> Acessar </li></ul>

</div>
<div style ="css_materiais.css"></div>

<?php $this->load->view('footer') ?>
