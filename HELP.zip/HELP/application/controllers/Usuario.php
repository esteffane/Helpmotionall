<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {
    

	public function index()
	{
        
    }
    public function formAdd(){
        $dados['pagina'] = "Cadastramento";
        $this->load->view('cadastro/index', $dados);
    }
    public function salvar()
    {
        $this->Usuario_model->login = $_POST['login'];
        $this->Usuario_model->senha = $_POST['senha'];
        $this->Usuario_model->inserir();
        $this->session->set_flashdata('success','Cadastrado com sucesso!');
        redirect(base_url().'index.php/home/');
    }
}
