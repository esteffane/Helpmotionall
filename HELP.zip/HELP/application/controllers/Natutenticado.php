<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Natutenticado extends CI_Controller {
    
	public function index()
	{
        
        $dados['pagina'] = "Materiais para ajuda";
        $dados['css_extra'] = "";
        $base_fundo =  base_url('assets/images/fundo.jpg');      
        $dados['fundo'] = $base_fundo;
        return $this->load->view('Nautenticado/index', $dados);
    }
    
}
