<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Materiais extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		
		if(!$this->session->userdata('usuario_logado')){
			redirect(base_url().'index.php/login/index');
		}
	}
    
	public function index()
	{
        
        $dados['pagina'] = "Materiais para ajuda";
        $dados['css_materiais'] = "";
        return $this->load->view('materiais/index', $dados);
    }
    
}
