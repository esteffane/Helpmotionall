<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quero extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		
		if(!$this->session->userdata('usuario_logado')){
			redirect(base_url().'index.php/login/index');
		}
	}
    
	public function index()
	{
		$dados['comentarios'] = $this->Comentario_model->recuperar();
		$dados['publics'] = $this->Publicacao_model->recuperar();
		$dados['pagina'] = "Quero ajudar";
        $dados['css_quero'] = "";
        return $this->load->view('quero/index', $dados);
	}
	public function salvar(){
		$this->Comentario_model->content = $_POST['content'];
		$this->Comentario_model->publicacao_id = $_POST['id_public'];
		$this->Comentario_model->inserir();
		$this->session->set_flashdata('success', "Comentário inserido com sucesso!");
		 return redirect(base_url().'index.php/quero/');
		
	}
	public function salvarUm(){
		$this->Comentario_model->content = $_POST['content'];
		$this->Comentario_model->publicacao_id = $_POST['id_public'];
		$this->Comentario_model->inserir();
		$this->session->set_flashdata('success', "Comentário inserido com sucesso!");
		 return redirect(base_url().'index.php/quero/ajudarUm/'.$_POST['id_public']);
		
	}
	public function ajudarUm($id){
		$dados['comentarios'] = $this->Comentario_model->recuperarComentsPublicacao($id);
		$dados['publics'] = $this->Publicacao_model->recuperarUm($id);
		$dados['pagina'] = "Quero ajudar uma pessoa";
        $dados['css_quero'] = "";
        return $this->load->view('quero/ajudar', $dados);
	}
	public function editar($id){
		$dados['pagina'] = "Editar";
		$dados['css_quero'] = "";
		$dados['comentario'] = $this->Comentario_model->recuperarUm($id);
		return $this->load->view('quero/editar', $dados);
	}
	public function atualizar(){


		$id = $_POST['id'];
		$this->Comentario_model->content =  $_POST['content'];
		$this->Comentario_model->update($id);
		$this->session->set_flashdata('success', "Comentário ataulizado com sucesso!");
		return redirect(base_url().'index.php/quero/');
   
	}
	public function deletar($id){
		$this->Comentario_model->delete($id);
		$this->session->set_flashdata('success', "Comentário excluído com sucesso!");
		return redirect(base_url().'index.php/quero/');
   

	}
    
}
