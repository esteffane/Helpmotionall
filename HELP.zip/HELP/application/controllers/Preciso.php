<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Preciso extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		
		if(!$this->session->userdata('usuario_logado')){
			redirect(base_url().'index.php/login/index');
		}
	}
    
	public function index()
	{
        $dados['publics'] = $this->Publicacao_model->recuperar();
        $dados['pagina'] = "Preciso de ajuda";
        $dados['css_preciso'] = "";
        return $this->load->view('preciso/index', $dados);
	}
	public function salvar(){
		$this->Publicacao_model->titulo = $_POST['titulo'];
		$this->Publicacao_model->conteudo = $_POST['conteudo'];
		
		$usuario_id = $this->session->userdata('usuario_logado')['id'];
		$usuario_id = intval($usuario_id);
		
		$this->Publicacao_model->usuario_id = $usuario_id;
		$this->Publicacao_model->inserir();
		$this->session->set_flashdata('success','Publicado com sucesso!');
        redirect(base_url().'index.php/preciso/');
	}
	public function editar($id){
		$dados['publicacao'] = $this->Publicacao_model->recuperarUm($id);
		$dados['pagina'] = "Editar ajuda";
		$dados['css_preciso'] = "";
		 $this->load->view('preciso/editar', $dados);
	}
	public function atualizar(){
		$this->Publicacao_model->titulo = $_POST['titulo'];
		$this->Publicacao_model->conteudo = $_POST['conteudo'];
		
		
		$this->Publicacao_model->id = $_POST['id'];
		$this->Publicacao_model->update();
		$this->session->set_flashdata('success','Publicação atualizada com sucesso!');
        redirect(base_url().'index.php/preciso/');
	}
	public function deletar($id){
		$this->Publicacao_model->delete($id);
		$this->session->set_flashdata('success','Publicação excluída com sucesso!');
        redirect(base_url().'index.php/preciso/');
	}
    
}
