<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    
	public function index()
	{
        $dados['pagina'] = "Login";
        $dados['css_login'] = "";
        return $this->load->view('auth/index', $dados);
    }
    public function autenticar(){
        $login = $this->input->post('login');
        $senha = $this->input->post('senha');
        
        $verificar = $this->Usuario_model->logar($login, $senha);
        
   
        if ($verificar){
            $arrayUser = array(
                'id' => $verificar['id'],
                'login' => $verificar['login'],
                
                );
            $this->session->set_userdata('usuario_logado', $arrayUser);
         
            $this->session->set_flashdata('success', 'Usuario logado');
            
            redirect(base_url().'index.php/home/index');
        }else{
            $this->session->set_flashdata('error', 'Usuario ou senha incorrentos');
            /*
            echo "non";
            echo "<br>";
            if($this->session->flashdata('error')){
                var_dump($this->session->flashdata('error'));
            }else{
                echo "retorna false";
            }
            
            
            exit();
            */
            redirect(base_url().'index.php/login/');
        }
    }
    public function logout(){
        $this->session->sess_destroy();
        redirect(base_url().'index.php/login/index');
    }
    
}
