<?php
class Comentario_model extends CI_Model
{
    public $id;
	public $content;
	public $data_hora_criacao;
	public $publicacao_id;
	
    
	public function __construct(){
		 parent::__construct();
	}
	public function inserir()
	{
        $dados = array("content" => $this->content,
                        "publicacao_id" => $this->publicacao_id
                    );
		return $this->db->insert('comentario',$dados);
	}
	public function recuperar(){
		$query = $this->db->order_by('id', 'DESC')->get('comentario');
		return $query->result();
	}
    public function recuperarComentsPublicacao($id_publicacao){
        $this->db->where('publicacao_id',$id_publicacao);
        $query = $this->db->get('comentario');
        return $query->result();
    }
	public function recuperarUm($id){
        $this->db->where('id',$id);
        $query = $this->db->get('comentario');
        return $query->row();
    }
	public function update($id){
        $this->db->set('content', $this->content);
        
        $this->db->where('id', $id);
        $this->db->update('comentario');
	}
	public function delete($id){
		$this->db->where('id', $id);
        $this->db->delete('comentario');
	}
}