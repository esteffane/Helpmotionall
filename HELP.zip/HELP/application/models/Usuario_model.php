<?php
class Usuario_model extends CI_Model
{
    public $id;
	public $login;
	public $senha;
	
	public function __construct(){
		 parent::__construct();
	}
	public function inserir()
	{
        $dados = array("login" => $this->login,
                        "senha" => $this->senha
                    );
		return $this->db->insert('usuario',$dados);
	}
	public function recuperar(){
		$query = $this->db->get('usuario');
		return $query->result();
	}
   
	public function recuperarUm($id){
        $this->db->where('id',$id);
        $query = $this->db->get('usuario');
        return $query->row();
    }
	public function update(){
        $this->db->set('login', $this->responsavel);
        $this->db->set('senha', $this->equipamento_id);
		
        $this->db->where('id', $this->id_os);
        $this->db->update('usuario');
	}
	
	//função para deletar uma meta.
	public function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('usuario');
    }
    //autenticação
	public function logar($login, $senha){
		$this->db->where('login', $login);
        $this->db->where('senha', $senha);
        $usuario = $this->db->get('usuario')->row_array();
        return $usuario;
	}
}