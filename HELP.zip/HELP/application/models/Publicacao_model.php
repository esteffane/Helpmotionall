<?php
class Publicacao_model extends CI_Model
{
    public $id;
	public $titulo;
	public $conteudo;
	public $data_hora_criacao;
	public $usuario_id;
	
    
	public function __construct(){
		 parent::__construct();
	}
	public function inserir()
	{
        $dados = array("titulo" => $this->titulo,
                        "conteudo" => $this->conteudo,
                        "usuario_id" => $this->usuario_id
                    );
		return $this->db->insert('publicacao',$dados);
	}
	public function recuperar(){
		$query = $this->db->order_by('id', 'DESC')->get('publicacao');
		return $query->result();
	}
   
	public function recuperarUm($id){
        $this->db->where('id',$id);
        $query = $this->db->get('publicacao');
        return $query->row();
    }
	public function update(){
        $this->db->set('titulo', $this->titulo);
        $this->db->set('conteudo', $this->conteudo);
		
        $this->db->where('id', $this->id);
        $this->db->update('publicacao');
	}
	public function delete($id){
		$this->db->where('id', $id);
        $this->db->delete('publicacao');
	}
}